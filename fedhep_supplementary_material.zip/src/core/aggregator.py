from typing import List, Optional, Dict, Tuple
import numpy as np
from src.core.interfaces import Aggregator, ClientState

import torch
import torch.nn as nn
import torch.nn.functional as F

class FedAvgAggregator(Aggregator):
    def aggregate(self, states: List[ClientState]) -> torch.Tensor:
        if not states:
            raise ValueError("Cannot aggregate empty list of states.")
        
        total_samples = sum(state.data_samples for state in states)
        stacked_weights = torch.stack([state.weights for state in states])
        if total_samples == 0:
            # Fallback to simple average
            return stacked_weights.mean(dim=0)
            
        # Weighted average based on number of local data samples via BLAS matrix-vector product (w^T A)
        device = states[0].weights.device
        sample_weights = torch.tensor(
            [state.data_samples / total_samples for state in states],
            device=device,
            dtype=states[0].weights.dtype
        )
        return sample_weights @ stacked_weights

class RandomizedAggregator(Aggregator):
    """
    Assigns a random weight to each client's update during aggregation.
    Can be used to test if random noise in aggregation provides any 
    inherent robustness against biased attacks.
    """
    def aggregate(self, states: List[ClientState]) -> torch.Tensor:
        if not states:
            raise ValueError("Cannot aggregate empty list of states.")
        
        device = states[0].weights.device
        weights = torch.rand(len(states), device=device, dtype=states[0].weights.dtype)
        normalized_weights = weights / weights.sum()
        stacked_weights = torch.stack([state.weights for state in states])
        return normalized_weights @ stacked_weights


class TrimmedMeanAggregator(Aggregator):
    """
    Coordinate-Wise Trimmed Mean Aggregator.
    Discards the top and bottom beta fraction of values per coordinate,
    providing provable Byzantine resilience against sign-flipping and gradient noise.
    """
    def __init__(self, beta: float = 0.20):
        self.beta = beta

    def aggregate(self, states: List[ClientState]) -> torch.Tensor:
        if not states:
            raise ValueError("Cannot aggregate empty list of states.")
        if len(states) <= 2:
            return torch.stack([s.weights for s in states]).mean(dim=0)

        stacked = torch.stack([s.weights for s in states], dim=0)
        return trimmed_mean(stacked, self.beta)


# ----------------------------------------------------------------------
# Delta-space robust aggregation primitives (tensor level)
# ----------------------------------------------------------------------

def trimmed_mean(stack: torch.Tensor, beta: float) -> torch.Tensor:
    """Coordinate-wise trimmed mean over dim 0 of a [N, D] stack."""
    n = stack.size(0)
    k = int(n * beta)
    if k == 0 or 2 * k >= n:
        return stack.mean(dim=0)
    sorted_stack, _ = torch.sort(stack, dim=0)
    return sorted_stack[k:n - k].mean(dim=0)


def coordinate_median(stack: torch.Tensor) -> torch.Tensor:
    """Coordinate-wise median over dim 0 of a [N, D] stack.

    Sort-based: torch.median(dim=0) is silently broken on some accelerators
    (DirectML CPU-fallback yields an empty values tensor). For even N this
    returns the true statistical median (mean of the two middle values).
    """
    sorted_stack, _ = torch.sort(stack, dim=0)
    n = sorted_stack.size(0)
    if n % 2 == 1:
        return sorted_stack[n // 2]
    return 0.5 * (sorted_stack[n // 2 - 1] + sorted_stack[n // 2])


def soft_cosine_trust(
    deltas: torch.Tensor,
    temperature: float = 0.5,
    hard_rejection: bool = False,
    hard_threshold: float = -0.1,
    adaptive_temperature: bool = False,
    active_masks: Optional[torch.Tensor] = None,
    classifier_slice: Optional[Tuple[int, int]] = None,
) -> torch.Tensor:
    """
    Trust weights from cosine similarity to the unit-normalized centroid, with
    optional skew-calibration, adaptive temperature scaling, and hard rejection.

    Sign-flipped updates point against the honest centroid, so they receive
    near-zero trust without any attack-specific heuristic. Trust is
    scale-invariant by construction; magnitude-inflation attacks are handled
    separately by bounding the deltas before the weighted combination
    (see DeltaSpaceRobustAggregator).

    deltas: [N, D] update vectors. Returns [N] trust weights summing to 1.
    """
    n = deltas.size(0)
    if n == 1:
        return torch.ones(1, device=deltas.device)

    # Skew-calibrated directional alignment: if active class masks are provided,
    # evaluate similarity specifically within the active parameter subspace of the classifier head
    if active_masks is not None and active_masks.size(0) == n:
        num_classes = active_masks.size(1)
        head_deltas = None
        if classifier_slice is not None:
            s_start, s_end = classifier_slice
            if s_end <= deltas.size(1) and (s_end - s_start) % num_classes == 0:
                head_deltas = deltas[:, s_start:s_end]
        elif deltas.size(1) == num_classes:
            head_deltas = deltas
        elif deltas.size(1) % num_classes == 0 and deltas.size(1) // num_classes <= 4096:
            head_deltas = deltas

        if head_deltas is not None:
            feature_dim = head_deltas.size(1) // num_classes
            mask = active_masks.float().to(deltas.device).unsqueeze(2).expand(n, num_classes, feature_dim).reshape(n, -1)
            unit_head = head_deltas * mask
            unit_head = F.normalize(unit_head, dim=1, eps=1e-10)
            centroid_head = unit_head.mean(dim=0)
            norm_centroid = centroid_head.norm()
            if norm_centroid < 0.2:
                return torch.full((n,), 1.0 / n, device=deltas.device)
            # Compare each client's update within its active class subspace against the consensus subspace
            centroid_masked = centroid_head.unsqueeze(0) * mask
            sims = F.cosine_similarity(unit_head, centroid_masked, dim=1, eps=1e-10)
        else:
            unit = F.normalize(deltas, dim=1, eps=1e-10)
            centroid = unit.mean(dim=0)
            norm_centroid = centroid.norm()
            if norm_centroid < 0.2:
                return torch.full((n,), 1.0 / n, device=deltas.device)
            sims = F.cosine_similarity(unit, centroid.unsqueeze(0).expand_as(unit), dim=1, eps=1e-10)
    else:
        unit = F.normalize(deltas, dim=1, eps=1e-10)
        centroid = unit.mean(dim=0)
        norm_centroid = centroid.norm()
        if norm_centroid < 0.2:
            return torch.full((n,), 1.0 / n, device=deltas.device)
        sims = F.cosine_similarity(unit, centroid.unsqueeze(0).expand_as(unit), dim=1, eps=1e-10)

    # Optional hard rejection: updates opposing consensus are masked out to -inf
    if hard_rejection:
        sims = torch.where(sims < hard_threshold, torch.tensor(-1e9, device=deltas.device), sims)
        if torch.all(sims <= -1e8):
            return torch.full((n,), 1.0 / n, device=deltas.device)

    # Adaptive temperature scaling: adjust temperature inversely with similarity variance
    curr_temp = temperature
    if adaptive_temperature and n > 1:
        valid_sims = sims[sims > -1e8]
        if valid_sims.size(0) > 1:
            sim_var = torch.var(valid_sims).item()
            if sim_var > 0.05:
                curr_temp = max(0.1, temperature * 0.9)
            else:
                curr_temp = min(2.0, temperature * 1.05)

    return F.softmax(sims / curr_temp, dim=0)


def _lower_quartile(v: torch.Tensor) -> torch.Tensor:
    """Lower-quartile element of a 1-D tensor (sort-based).

    Used as the norm-bounding anchor because a median anchor can be inflated
    by the very attacks it is meant to bound when they are numerous.
    """
    s = torch.sort(v).values
    idx = min(s.size(0) - 1, int(0.25 * s.size(0)))
    return s[idx]


def bound_update_norms(stacked: torch.Tensor, k: float) -> torch.Tensor:
    """Clamp each update's norm to k * lower-quartile norm (row-wise rescale).

    Neutralizes magnitude-inflation attacks before trust-weighted summation;
    direction-preserving, so downstream cosine statistics are unchanged.
    The quartile anchor (rather than median/mean) keeps the allowance immune
    to attackers inflating the statistic with their own oversized updates.
    """
    if k is None or k <= 0:
        return stacked
    norms = stacked.norm(dim=1)
    lq = _lower_quartile(norms)
    scale = torch.where(norms > 1e-8, (k * lq / norms).clamp(max=1.0), torch.ones_like(norms))
    return stacked * scale.unsqueeze(1)


class DeltaSpaceRobustAggregator:
    """
    Server-side robust aggregation over client update deltas.

    Aggregates deltas (w_i - w_ref) instead of raw weights so that directional
    statistics (cosine trust) and coordinate-wise trimming are meaningful, then
    maps back through the reference. BatchNorm running buffers can optionally
    be aggregated via coordinate-wise median, since poisoned statistics are an
    attack vector that parametric filtering alone does not cover.

    Features:
    - Sentinel NaN/Inf guard dropping corrupted or exploding updates.
    - Directional unit-normalization and quartile norm bounding against magnitude inflation.
    - Skew-calibrated soft cosine rejection protecting specialized non-IID clients.
    - Adaptive temperature scaling and trust reputation tracking.
    """
    def __init__(self, mode: str = "soft_cosine", beta: float = 0.20,
                 temperature: float = 0.5, norm_bound_k: float = 3.0,
                 buffer_slices=None, classifier_slice=None, adaptive_temperature: bool = False,
                 hard_rejection: bool = False, hard_threshold: float = -0.1):
        if mode not in ("trimmed_mean", "soft_cosine"):
            raise ValueError(f"Unknown robust aggregation mode '{mode}'")
        self.mode = mode
        self.beta = beta
        self.temperature = temperature
        self.norm_bound_k = norm_bound_k
        self.adaptive_temperature = adaptive_temperature
        self.hard_rejection = hard_rejection
        self.hard_threshold = hard_threshold
        # Optional list of (start, end) index ranges marking buffer coordinates
        # in the flattened parameter vector (e.g. BN running stats).
        self.buffer_slices = buffer_slices or []
        self.classifier_slice = classifier_slice
        if self.buffer_slices and self.classifier_slice:
            s_start, s_end = self.classifier_slice
            shift = sum(e - s for s, e in self.buffer_slices if e <= s_start)
            self._param_classifier_slice = (s_start - shift, s_end - shift)
        else:
            self._param_classifier_slice = self.classifier_slice
        self._idx_cache = {}
        self.last_trust_scores: Optional[torch.Tensor] = None

    def _split_indices(self, dim: int, device):
        """Cached (param_idx, buffer_idx) integer index tensors."""
        key = (dim, str(device))
        if key not in self._idx_cache:
            buf = []
            for start, end in self.buffer_slices:
                buf.extend(range(start, end))
            buf_set = set(buf)
            keep = [i for i in range(dim) if i not in buf_set]
            self._idx_cache[key] = (
                torch.tensor(keep, dtype=torch.long, device=device),
                torch.tensor(buf, dtype=torch.long, device=device),
            )
        return self._idx_cache[key]

    def aggregate_deltas(self, deltas: List[torch.Tensor], reference: torch.Tensor = None,
                         active_masks: Optional[torch.Tensor] = None) -> torch.Tensor:
        if not deltas:
            raise ValueError("Cannot aggregate empty list of deltas.")
        
        # Sentinel Pre-filter: drop any updates containing NaN or Inf
        clean_indices = [i for i, d in enumerate(deltas) if not (torch.isnan(d).any() or torch.isinf(d).any())]
        clean_deltas = [deltas[i] for i in clean_indices]
        if not clean_deltas:
            # If all updates contain NaNs, immediately return a zero delta to leave the reference unchanged
            self.last_trust_scores = torch.zeros(len(deltas), device=deltas[0].device)
            return torch.zeros_like(deltas[0])

        if active_masks is not None and active_masks.size(0) == len(deltas) and len(clean_indices) < len(deltas):
            active_masks = active_masks[clean_indices]

        stacked = torch.stack(clean_deltas, dim=0).float()
        out_dtype = stacked.dtype

        if self.buffer_slices:
            dim = stacked.size(1)
            param_idx, buf_idx = self._split_indices(dim, stacked.device)
            agg = torch.empty_like(stacked[0])
            agg.index_copy_(0, param_idx,
                            self._aggregate_param_deltas(stacked.index_select(1, param_idx), active_masks).float())
            agg.index_copy_(0, buf_idx,
                            coordinate_median(stacked.index_select(1, buf_idx)).float())
            return agg.to(out_dtype)
        return self._aggregate_param_deltas(stacked, active_masks).float()

    def _aggregate_param_deltas(self, stacked: torch.Tensor, active_masks: Optional[torch.Tensor] = None) -> torch.Tensor:
        if self.mode == "trimmed_mean":
            return trimmed_mean(stacked, self.beta)
        bounded = bound_update_norms(stacked, self.norm_bound_k)
        trust = soft_cosine_trust(
            bounded,
            temperature=self.temperature,
            hard_rejection=self.hard_rejection,
            hard_threshold=self.hard_threshold,
            adaptive_temperature=self.adaptive_temperature,
            active_masks=active_masks,
            classifier_slice=self._param_classifier_slice,
        )
        self.last_trust_scores = trust.detach().clone()
        return (trust.unsqueeze(1) * bounded).sum(dim=0)

    def get_last_trust_scores(self) -> Optional[torch.Tensor]:
        return self.last_trust_scores


def compute_buffer_slices(model: nn.Module):
    """(start, end) flat-vector ranges of state_dict entries that are buffers
    (e.g. BatchNorm running_mean/var), following model_to_vector's ordering.

    Uses state-dict key sets rather than tensor storage pointers so it works
    on accelerators that do not expose data_ptr (e.g. DirectML).
    """
    param_keys = {k for k, _ in model.named_parameters()}
    slices = []
    offset = 0
    for key, v in model.state_dict().items():
        numel = v.numel()
        if key not in param_keys:
            slices.append((offset, offset + numel))
        offset += numel
    return slices


def compute_classifier_slices(model: nn.Module) -> Optional[Tuple[int, int]]:
    """(start, end) flat-vector range of primary classifier linear head weight
    of shape [num_classes, feature_dim].
    """
    offset = 0
    for key, v in model.state_dict().items():
        numel = v.numel()
        if (
            ("fc2_root" in key or "fc2" in key or "classifier_root.3" in key or "classifier" in key)
            and key.endswith(".weight")
            and v.dim() == 2
        ):
            return (offset, offset + numel)
        offset += numel
    return None

